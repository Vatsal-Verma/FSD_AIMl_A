const { readfile, writefile } = require("./fileSync1");

readfile();
writefile()
readfile()